# TP Module 3 — Liste des étudiants (XML, XPath, XSLT, CSS)

**Étudiant :** Mouhamed Niang  
**Matricule de travail :** ISEP26-013

## Contenu
- `etudiants.xml` : données des 12 étudiants fournies dans le TP.
- `liste.xsl` : feuille XSLT de l'étape 3.
- `tableau.xsl` : réalisation des étapes 4 à 8 (statistiques, moyennes, tri, classes).
- `style.css` : mise en forme de la page.
- `reponses-tp3e.txt` : réponses aux questions XPath et sortie manuelle.

## Ouvrir dans Visual Studio Code
1. Décompressez le dossier.
2. Dans VS Code, cliquez sur **Fichier > Ouvrir le dossier**.
3. Sélectionnez `tp3-etudiants-mouhamed-niang`.
4. Ouvrez les fichiers XML, XSL, CSS ou TXT pour les consulter et les modifier.

## Générer la page HTML
Le sujet précise que les feuilles XSLT ne s'exécutent pas directement dans VS Code. Vous pouvez les écrire dans VS Code puis les exécuter avec un processeur XSLT 1.0 (par exemple Saxon 6 ou `xsltproc`, si installé).

Avec `xsltproc` :
```bash
xsltproc tableau.xsl etudiants.xml > resultat.html
```
Ensuite, ouvrez `resultat.html` dans un navigateur. Gardez `style.css` dans le même dossier.

Pour générer la liste :
```bash
xsltproc liste.xsl etudiants.xml > liste.html
```

## Identité
Le commentaire en tête des feuilles contient `ISEP26-013 — NIANG Mouhamed`. Ce matricule est une proposition de travail, pas une confirmation d'un matricule officiel.
